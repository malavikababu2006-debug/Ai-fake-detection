"""Flask API for review classification, persistence, and model reporting."""
from __future__ import annotations

import json
import os
import re
import sqlite3
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any

from flask import Flask, current_app, jsonify, render_template, request
from skops import io as skops_io

ROOT = Path(__file__).resolve().parent
MODEL_TYPES = {
    "sklearn.feature_extraction.text.TfidfVectorizer",
    "sklearn.linear_model._logistic.LogisticRegression",
    "sklearn.pipeline.Pipeline",
}
WORD_PATTERN = re.compile(r"\b[\w']+\b", re.UNICODE)
PROMOTIONAL_TERMS = re.compile(
    r"\b(buy now|must buy|best ever|life changing|100% recommend|unbeatable|"
    r"limited offer|five stars|5 stars|perfect product|highly recommend)\b",
    re.IGNORECASE,
)
GENERIC_PHRASES = re.compile(
    r"\b(great product|excellent product|works as expected|good quality|"
    r"highly recommended|very good product)\b",
    re.IGNORECASE,
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def review_indicators(text: str) -> list[dict[str, Any]]:
    """Describe possible cues; these heuristics do not decide the ML label."""
    words = WORD_PATTERN.findall(text.lower())
    repeated = [word for word, count in Counter(words).items() if len(word) > 3 and count >= 4]
    punctuation_runs = re.findall(r"[!?]{2,}", text)
    promotional = bool(PROMOTIONAL_TERMS.search(text))
    generic = bool(GENERIC_PHRASES.search(text))
    short_or_long = len(words) < 8 or len(words) > 180
    return [
        {"key": "promotional_language", "label": "Promotional wording", "detail": "Contains language commonly used in promotions or strong endorsements." if promotional else "No common promotional phrases were detected.", "present": promotional},
        {"key": "repetition", "label": "Repeated words", "detail": f"Repeated terms: {', '.join(repeated[:3])}." if repeated else "No strongly repeated terms were detected.", "present": bool(repeated)},
        {"key": "generic_wording", "label": "Generic wording", "detail": "Uses a short, generic product endorsement phrase." if generic else "No common generic endorsement phrase was detected.", "present": generic},
        {"key": "punctuation", "label": "Emphatic punctuation", "detail": "Contains repeated exclamation or question marks." if punctuation_runs else "Punctuation appears within an ordinary range.", "present": bool(punctuation_runs)},
        {"key": "unusual_length", "label": "Unusual review length", "detail": "Very short or unusually long reviews can be harder to interpret." if short_or_long else "Review length is within a typical range.", "present": short_or_long},
    ]


def connect_db() -> sqlite3.Connection:
    database_path = Path(current_app.config["DATABASE_PATH"])
    database_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database_path)
    connection.row_factory = sqlite3.Row
    return connection


@contextmanager
def database_session():
    connection = connect_db()
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_database(app: Flask) -> None:
    database_path = Path(app.config["DATABASE_PATH"])
    database_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database_path)
    try:
        with connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS review_analyses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_name TEXT,
                    rating REAL CHECK (rating IS NULL OR rating BETWEEN 1 AND 5),
                    review_text TEXT NOT NULL,
                    prediction TEXT NOT NULL CHECK (prediction IN ('Fake', 'Genuine')),
                    probability REAL NOT NULL CHECK (probability BETWEEN 0 AND 1),
                    indicators_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )"""
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_review_analyses_created_at ON review_analyses(created_at)"
            )
    finally:
        connection.close()


@lru_cache(maxsize=4)
def load_model(model_path: str):
    """Load the app-trained artifact only; arbitrary uploaded model files are never accepted."""
    path = Path(model_path)
    if not path.is_file():
        raise FileNotFoundError("Model not found. Run python train_model.py to train it.")
    untrusted_types = skops_io.get_untrusted_types(file=path)
    unexpected_types = set(untrusted_types) - MODEL_TYPES
    if unexpected_types:
        raise ValueError(f"Model contains unapproved serialized types: {', '.join(sorted(unexpected_types))}")
    return skops_io.load(path, trusted=untrusted_types)


def read_metrics(metrics_path: str) -> dict[str, Any] | None:
    try:
        with Path(metrics_path).open(encoding="utf-8") as metrics_file:
            metrics = json.load(metrics_file)
        return metrics if isinstance(metrics, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def create_app(test_config: dict[str, Any] | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_mapping(
        DATABASE_PATH=os.environ.get("DATABASE_PATH", str(ROOT / "instance" / "reviews.db")),
        MODEL_PATH=os.environ.get("MODEL_PATH", str(ROOT / "model" / "review_classifier.skops")),
        METRICS_PATH=os.environ.get("METRICS_PATH", str(ROOT / "model" / "evaluation.json")),
        MAX_CONTENT_LENGTH=128 * 1024,
    )
    if test_config:
        app.config.update(test_config)
    initialize_database(app)

    @app.errorhandler(413)
    def payload_too_large(_error):
        return jsonify({"error": "Request is too large. Review text must be 5,000 characters or fewer."}), 413

    @app.get("/")
    @app.get("/demo")
    def demo():
        return render_template("demo.html")

    @app.get("/api/health")
    def health():
        try:
            load_model(app.config["MODEL_PATH"])
            model_available = True
        except Exception:
            app.logger.warning("The trained model is unavailable or could not be loaded")
            model_available = False
        return jsonify({"status": "ok", "model_available": model_available})

    @app.post("/api/predict")
    def predict():
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Send a JSON object containing review text."}), 400
        review = payload.get("review")
        if not isinstance(review, str) or not review.strip():
            return jsonify({"error": "Enter a review before running the analysis."}), 400
        review = review.strip()
        if len(review) < 8:
            return jsonify({"error": "Please enter at least 8 characters so the model has enough context."}), 400
        if len(review) > 5_000:
            return jsonify({"error": "Review text must be 5,000 characters or fewer."}), 400

        product = payload.get("product")
        product = product.strip()[:120] if isinstance(product, str) and product.strip() else None
        rating = payload.get("rating")
        if rating in (None, ""):
            rating_value = None
        elif isinstance(rating, bool):
            return jsonify({"error": "Rating must be a number between 1 and 5."}), 400
        else:
            try:
                rating_value = float(rating)
            except (TypeError, ValueError):
                return jsonify({"error": "Rating must be a number between 1 and 5."}), 400
            if not 1 <= rating_value <= 5:
                return jsonify({"error": "Rating must be between 1 and 5."}), 400

        try:
            model = load_model(app.config["MODEL_PATH"])
            prediction = str(model.predict([review])[0])
            class_probabilities = model.predict_proba([review])[0]
            class_index = list(model.classes_).index(prediction)
            probability = float(class_probabilities[class_index])
        except (OSError, ValueError, ImportError, AttributeError, IndexError):
            app.logger.exception("The review model could not be loaded or used")
            return jsonify({"error": "The trained review model is unavailable. Run python train_model.py, then try again."}), 503
        except Exception:
            app.logger.exception("Unexpected prediction error")
            return jsonify({"error": "The model could not analyze this review. Please try again."}), 500

        indicators = review_indicators(review)
        created_at = utc_now()
        with database_session() as connection:
            cursor = connection.execute(
                """INSERT INTO review_analyses
                   (product_name, rating, review_text, prediction, probability, indicators_json, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (product, rating_value, review, prediction, probability, json.dumps(indicators), created_at),
            )
            analysis_id = cursor.lastrowid

        return jsonify({
            "id": analysis_id,
            "prediction": prediction,
            "probability": probability,
            "indicators": indicators,
            "created_at": created_at,
            "notice": "Model probability is not calibrated. Indicators are signals, not proof of authenticity.",
        })

    @app.get("/api/dashboard")
    def dashboard():
        with database_session() as connection:
            totals = connection.execute(
                """SELECT COUNT(*) AS total,
                   SUM(CASE WHEN prediction = 'Fake' THEN 1 ELSE 0 END) AS fake,
                   SUM(CASE WHEN prediction = 'Genuine' THEN 1 ELSE 0 END) AS genuine
                   FROM review_analyses"""
            ).fetchone()
            daily_rows = connection.execute(
                """SELECT date(created_at) AS day, COUNT(*) AS total,
                   SUM(CASE WHEN prediction = 'Fake' THEN 1 ELSE 0 END) AS fake,
                   SUM(CASE WHEN prediction = 'Genuine' THEN 1 ELSE 0 END) AS genuine
                   FROM review_analyses
                   WHERE created_at >= datetime('now', '-13 days')
                   GROUP BY date(created_at) ORDER BY day"""
            ).fetchall()
        return jsonify({
            "total": totals["total"] or 0,
            "fake": totals["fake"] or 0,
            "genuine": totals["genuine"] or 0,
            "daily_activity": [dict(row) for row in daily_rows],
        })

    @app.get("/api/history")
    def history():
        try:
            limit = min(max(int(request.args.get("limit", 50)), 1), 100)
        except ValueError:
            return jsonify({"error": "History limit must be a whole number."}), 400
        with database_session() as connection:
            rows = connection.execute(
                """SELECT id, product_name, rating, prediction, probability, created_at
                   FROM review_analyses ORDER BY id DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return jsonify({"items": [dict(row) for row in rows]})

    @app.get("/api/evaluation")
    def evaluation():
        metrics = read_metrics(app.config["METRICS_PATH"])
        if metrics is None:
            return jsonify({"available": False, "message": "Evaluation metrics are not available yet. Run python train_model.py."})
        return jsonify({"available": True, **metrics})

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=os.environ.get("FLASK_DEBUG") == "1")
