import json
import tempfile
import unittest
from pathlib import Path

from app import create_app, review_indicators


class ReviewApiTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)
        self.app = create_app({
            "TESTING": True,
            "DATABASE_PATH": str(root / "reviews.db"),
            "MODEL_PATH": str(root / "missing.skops"),
            "METRICS_PATH": str(root / "missing.json"),
        })
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_invalid_payload_is_rejected(self):
        response = self.client.post("/api/predict", json={"review": "  "})
        self.assertEqual(response.status_code, 400)
        self.assertIn("Enter a review", response.json["error"])

    def test_short_review_is_rejected(self):
        response = self.client.post("/api/predict", json={"review": "Nice"})
        self.assertEqual(response.status_code, 400)

    def test_invalid_rating_is_rejected(self):
        response = self.client.post("/api/predict", json={"review": "This is a longer review.", "rating": 8})
        self.assertEqual(response.status_code, 400)
        self.assertIn("between 1 and 5", response.json["error"])
        boolean_rating = self.client.post("/api/predict", json={"review": "This is a longer review.", "rating": True})
        self.assertEqual(boolean_rating.status_code, 400)

    def test_missing_model_returns_clear_service_error(self):
        response = self.client.post("/api/predict", json={"review": "This review has enough words to analyze."})
        self.assertEqual(response.status_code, 503)
        self.assertIn("trained review model is unavailable", response.json["error"])

    def test_dashboard_and_history_start_empty(self):
        self.assertEqual(self.client.get("/api/dashboard").json["total"], 0)
        self.assertEqual(self.client.get("/api/history").json["items"], [])

    def test_evaluation_is_not_invented_when_missing(self):
        response = self.client.get("/api/evaluation")
        self.assertFalse(response.json["available"])
        self.assertIn("train_model.py", response.json["message"])

    def test_indicators_are_labeled_as_possible_signals(self):
        indicators = review_indicators("Buy now! Amazing product, buy now!!!")
        self.assertTrue(next(item for item in indicators if item["key"] == "promotional_language")["present"])
        self.assertTrue(next(item for item in indicators if item["key"] == "punctuation")["present"])

    def test_model_unavailable_health_does_not_crash(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json["model_available"])

    def test_flask_template_is_connected(self):
        response = self.client.get("/demo")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Analyze a product review", response.data)

    def test_trained_model_predicts_and_history_hides_review_text(self):
        root = Path(self.temp_dir.name)
        trained_app = create_app({
            "TESTING": True,
            "DATABASE_PATH": str(root / "trained.db"),
            "MODEL_PATH": str(Path(__file__).resolve().parents[1] / "model" / "review_classifier.skops"),
            "METRICS_PATH": str(Path(__file__).resolve().parents[1] / "model" / "evaluation.json"),
        })
        client = trained_app.test_client()
        prediction = client.post("/api/predict", json={
            "review": "The battery lasts three days and the earbuds connect quickly to my phone.",
            "product": "Wireless headphones",
            "rating": 4,
        })
        self.assertEqual(prediction.status_code, 200, prediction.json)
        self.assertIn(prediction.json["prediction"], {"Fake", "Genuine"})
        self.assertGreaterEqual(prediction.json["probability"], 0)
        self.assertLessEqual(prediction.json["probability"], 1)
        self.assertEqual(len(prediction.json["indicators"]), 5)
        history = client.get("/api/history").json["items"]
        self.assertEqual(len(history), 1)
        self.assertNotIn("review_text", history[0])
        self.assertEqual(client.get("/api/dashboard").json["total"], 1)
        self.assertTrue(client.get("/api/evaluation").json["available"])


if __name__ == "__main__":
    unittest.main()
