"""Train and evaluate the TF-IDF + Logistic Regression review classifier."""
from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from skops import io as sio

ROOT = Path(__file__).resolve().parent
DEFAULT_DATASET = ROOT / "dataset" / "reviews.csv"
DEFAULT_MODEL = ROOT / "model" / "review_classifier.skops"
DEFAULT_METRICS = ROOT / "model" / "evaluation.json"
LABELS = {"fake": "Fake", "genuine": "Genuine", "0": "Fake", "1": "Genuine"}


def load_dataset(csv_path: Path) -> tuple[list[str], list[str]]:
    texts: list[str] = []
    labels: list[str] = []
    with csv_path.open(newline="", encoding="utf-8-sig") as source:
        reader = csv.DictReader(source)
        if not reader.fieldnames or not {"review", "label"}.issubset(reader.fieldnames):
            raise ValueError("CSV must contain columns named 'review' and 'label'.")
        for line_number, row in enumerate(reader, start=2):
            text = (row.get("review") or "").strip()
            raw_label = (row.get("label") or "").strip().lower()
            label = LABELS.get(raw_label)
            if not text or label is None:
                raise ValueError(f"Invalid review or label on CSV line {line_number}.")
            texts.append(text)
            labels.append(label)
    if len(texts) < 8 or min(labels.count("Fake"), labels.count("Genuine")) < 4:
        raise ValueError("Provide at least 8 labeled reviews and at least 4 examples per class.")
    return texts, labels


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--model-out", type=Path, default=DEFAULT_MODEL)
    parser.add_argument("--metrics-out", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--test-size", type=float, default=0.25)
    args = parser.parse_args()
    if not 0.1 <= args.test_size <= 0.5:
        parser.error("--test-size must be between 0.1 and 0.5")

    texts, labels = load_dataset(args.dataset)
    # Stratification preserves the class mix in both train and held-out test data.
    x_train, x_test, y_train, y_test = train_test_split(
        texts, labels, test_size=args.test_size, random_state=42, stratify=labels
    )
    # Word unigrams and bigrams keep the baseline interpretable while capturing short phrases.
    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(
            lowercase=True,
            strip_accents="unicode",
            ngram_range=(1, 2),
            min_df=1,
            max_features=30_000,
            sublinear_tf=True,
            token_pattern=r"(?u)\b\w+\b",
        )),
        ("classifier", LogisticRegression(
            max_iter=1_000,
            class_weight="balanced",
            random_state=42,
        )),
    ])
    pipeline.fit(x_train, y_train)
    predicted = pipeline.predict(x_test)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_test, predicted, labels=["Fake", "Genuine"], average="macro", zero_division=0
    )
    matrix = confusion_matrix(y_test, predicted, labels=["Fake", "Genuine"])
    metrics = {
        "accuracy": float(accuracy_score(y_test, predicted)),
        "precision_macro": float(precision),
        "recall_macro": float(recall),
        "f1_macro": float(f1),
        "labels": ["Fake", "Genuine"],
        "confusion_matrix": matrix.tolist(),
        "classification_report": classification_report(
            y_test, predicted, labels=["Fake", "Genuine"], output_dict=True, zero_division=0
        ),
        "dataset_size": len(texts),
        "training_size": len(x_train),
        "test_size": len(x_test),
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "evaluation_note": "Held-out split of the supplied dataset. Sample CSV data is illustrative and does not estimate real-world performance. Logistic Regression probabilities are not calibrated.",
    }

    args.model_out.parent.mkdir(parents=True, exist_ok=True)
    args.metrics_out.parent.mkdir(parents=True, exist_ok=True)
    # skops lets the serving app inspect serialized types before trusting the model artifact.
    sio.dump(pipeline, args.model_out)
    args.metrics_out.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    print(f"Trained on {len(x_train)} reviews; evaluated on {len(x_test)} held-out reviews.")
    print(f"Accuracy: {metrics['accuracy']:.3f} | Macro precision: {precision:.3f} | Macro recall: {recall:.3f} | Macro F1: {f1:.3f}")
    print(f"Model saved to {args.model_out}")
    print(f"Metrics saved to {args.metrics_out}")


if __name__ == "__main__":
    main()


