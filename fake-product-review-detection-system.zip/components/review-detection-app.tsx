'use client'

import { useMemo, useState, type FormEvent } from 'react'
import useSWR, { useSWRConfig } from 'swr'
import {
  Activity,
  ArrowRight,
  BarChart3,
  Check,
  ChevronRight,
  CircleAlert,
  Clock3,
  Database,
  FileSearch,
  FlaskConical,
  History,
  LayoutDashboard,
  Menu,
  MessageSquareText,
  SearchCheck,
  ShieldCheck,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
  X,
  Zap,
} from 'lucide-react'
import { ReviewCharts } from '@/components/review-charts'

type View = 'overview' | 'analyze' | 'history' | 'evaluation'
type Indicator = { key: string; label: string; detail: string; present: boolean }
type Analysis = {
  id: number
  prediction: 'Fake' | 'Genuine'
  probability: number
  indicators: Indicator[]
  created_at: string
  notice: string
}
type Dashboard = {
  total: number
  fake: number
  genuine: number
  daily_activity: { day: string; total: number; fake: number; genuine: number }[]
}
type HistoryRow = {
  id: number
  product_name: string | null
  rating: number | null
  prediction: 'Fake' | 'Genuine'
  probability: number
  created_at: string
}
type Evaluation = {
  available: boolean
  accuracy?: number
  precision_macro?: number
  recall_macro?: number
  f1_macro?: number
  dataset_size?: number
  training_size?: number
  test_size?: number
  trained_at?: string
  labels?: string[]
  confusion_matrix?: number[][]
  evaluation_note?: string
  message?: string
}

const fetcher = async (url: string) => {
  const response = await fetch(url, { cache: 'no-store' })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error ?? 'The service could not complete this request.')
  return data
}

const navigation: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'analyze', label: 'Analyze a review', icon: SearchCheck },
  { id: 'history', label: 'Analysis history', icon: History },
  { id: 'evaluation', label: 'Model evaluation', icon: BarChart3 },
]

function formatDate(value: string) {
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(value))
}

function StatusPill({ prediction }: { prediction: 'Fake' | 'Genuine' }) {
  const genuine = prediction === 'Genuine'
  return <span className={`status-pill ${genuine ? 'status-genuine' : 'status-fake'}`}><span aria-hidden="true" className="status-dot" />{genuine ? 'Likely genuine' : 'Potentially fake'}</span>
}

function EmptyData({ title, detail }: { title: string; detail: string }) {
  return <div className="empty-state"><span className="empty-icon"><Activity size={19} /></span><strong>{title}</strong><p>{detail}</p></div>
}

function SignalList({ indicators }: { indicators: Indicator[] }) {
  return <ul className="signal-list">{indicators.map((indicator) => <li className="signal-row" key={indicator.key}><span className={`signal-icon ${indicator.present ? 'signal-detected' : 'signal-clear'}`} aria-hidden="true">{indicator.present ? <CircleAlert size={15} /> : <Check size={15} />}</span><div><strong>{indicator.label}</strong><p>{indicator.detail}</p></div><span className={`signal-tag ${indicator.present ? 'tag-detected' : 'tag-clear'}`}>{indicator.present ? 'Observed' : 'Not observed'}</span></li>)}</ul>
}

function RecentAnalyses({ rows, onViewAll }: { rows: HistoryRow[]; onViewAll: () => void }) {
  return <section className="panel recent-panel"><div className="panel-heading"><div><h2>Recent analyses</h2><p>Your latest review checks</p></div><button className="text-button" onClick={onViewAll}>View history <ArrowRight size={15} /></button></div>{rows.length ? <div className="recent-list">{rows.slice(0, 4).map((row) => <div className="recent-row" key={row.id}><span className={`recent-icon ${row.prediction === 'Genuine' ? 'recent-icon-good' : 'recent-icon-warn'}`}>{row.prediction === 'Genuine' ? <ThumbsUp size={16} /> : <ThumbsDown size={16} />}</span><div className="recent-details"><strong>{row.product_name || 'Product review'}</strong><span>{formatDate(row.created_at)}</span></div><StatusPill prediction={row.prediction} /><span className="recent-probability">{Math.round(row.probability * 100)}%</span></div>)}</div> : <EmptyData title="Your workspace is ready" detail="Analyze a review to see your recent activity here." />}</section>
}

function MetricCard({ label, value, hint }: { label: string; value: number | undefined; hint?: string }) {
  return <article className="metric-card"><span>{label}</span><strong>{value === undefined ? '—' : `${(value * 100).toFixed(1)}%`}</strong><div className="metric-track"><span style={{ width: `${(value ?? 0) * 100}%` }} /></div>{hint && <small>{hint}</small>}</article>
}

export function ReviewDetectionApp() {
  const [view, setView] = useState<View>('overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [review, setReview] = useState('')
  const [product, setProduct] = useState('')
  const [rating, setRating] = useState('')
  const [analysis, setAnalysis] = useState<Analysis | null>(null)
  const [formError, setFormError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { mutate } = useSWRConfig()
  const { data: dashboard, error: dashboardError } = useSWR<Dashboard>('/api/dashboard', fetcher, { refreshInterval: 15_000 })
  const { data: historyData, error: historyError } = useSWR<{ items: HistoryRow[] }>('/api/history?limit=40', fetcher, { refreshInterval: 15_000 })
  const { data: evaluation, error: evaluationError } = useSWR<Evaluation>('/api/evaluation', fetcher)
  const recent = historyData?.items ?? []
  const genuinePercent = useMemo(() => dashboard?.total ? Math.round((dashboard.genuine / dashboard.total) * 100) : 0, [dashboard])
  const activePage = navigation.find((item) => item.id === view)

  async function submitReview(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setFormError('')
    setAnalysis(null)
    setIsSubmitting(true)
    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ review, product, rating }),
      })
      const result = await response.json()
      if (!response.ok) throw new Error(result.error ?? 'The review could not be analyzed.')
      setAnalysis(result as Analysis)
      await Promise.all([mutate('/api/dashboard'), mutate('/api/history?limit=40')])
    } catch (error) {
      setFormError(error instanceof Error ? error.message : 'The review could not be analyzed. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  function navigate(nextView: View) {
    setView(nextView)
    setSidebarOpen(false)
  }

  return <div className="app-shell">
    {sidebarOpen && <button aria-label="Close navigation" className="mobile-scrim" onClick={() => setSidebarOpen(false)} />}
    <aside className={`app-sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
      <a className="brand-lockup" href="#overview" onClick={(event) => { event.preventDefault(); navigate('overview') }}><span className="brand-mark"><ShieldCheck size={21} strokeWidth={2.2} /></span><span><strong>Proofline</strong><small>REVIEW INTELLIGENCE</small></span></a>
      <div className="sidebar-section-label">WORKSPACE</div>
      <nav className="primary-nav" aria-label="Main navigation">{navigation.map((item) => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${view === item.id ? 'nav-item-active' : ''}`} onClick={() => navigate(item.id)} aria-current={view === item.id ? 'page' : undefined}><Icon size={18} strokeWidth={1.8} /><span>{item.label}</span>{item.id === 'history' && recent.length > 0 && <span className="nav-count">{recent.length}</span>}</button> })}</nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-model-card"><div className="model-card-icon"><FlaskConical size={17} /></div><div><strong>TF–IDF + Logistic Regression</strong><span>Baseline text classifier</span></div><span aria-label={evaluation?.available ? 'Model trained' : 'Model not trained'} className={`model-live-dot ${evaluation?.available ? '' : 'model-dot-muted'}`} /></div>
      <div className="sidebar-footer"><span className="sidebar-footer-mark"><Zap size={14} /></span><span>Built for transparent analysis</span></div>
    </aside>

    <div className="app-main-column">
      <header className="topbar"><button className="mobile-menu" aria-label="Open navigation" onClick={() => setSidebarOpen(true)}><Menu size={20} /></button><div className="breadcrumb">Workspace <ChevronRight size={14} /><span>{activePage?.label ?? 'Overview'}</span></div><div className="topbar-right"><span className="service-indicator"><span className={`service-dot ${dashboardError ? 'service-dot-error' : ''}`} />{dashboardError ? 'Service unavailable' : 'Flask analysis API'}</span><span className="topbar-separator" /><span className="topbar-date">AI / NLP</span></div></header>

      <main className="page-content">
        {view === 'overview' && <>
          <section className="hero-panel"><div className="hero-copy"><div className="eyebrow"><span className="eyebrow-line" /> AI-POWERED REVIEW INTELLIGENCE</div><h1>AI-Based Fake<br className="hero-break" /> Product Review Detection</h1><p className="hero-description">Detect suspicious and potentially fake product reviews using Artificial Intelligence and Natural Language Processing.</p><div className="hero-actions"><button className="button-primary" onClick={() => navigate('analyze')}>Analyze a Review <ArrowRight size={17} /></button><button className="button-secondary" onClick={() => navigate('evaluation')}>Explore the model</button></div><div className="hero-footnote"><ShieldCheck size={15} /> Signals for context. Never a claim of certainty.</div></div><div className="hero-graphic" aria-hidden="true"><div className="graphic-orbit graphic-orbit-one" /><div className="graphic-orbit graphic-orbit-two" /><div className="graphic-core"><span><MessageSquareText size={30} /></span></div><div className="graphic-chip chip-top"><span className="chip-good" /><span>Review signals</span><strong>5 checks</strong></div><div className="graphic-chip chip-bottom"><span className="chip-spark"><Sparkles size={14} /></span><span>Text model</span><strong>TF–IDF</strong></div><div className="graphic-node node-left"><Check size={13} /></div><div className="graphic-node node-right"><Activity size={14} /></div></div></section>
          <section className="feature-strip" aria-label="System features"><div className="feature-item"><span className="feature-icon feature-blue"><SearchCheck size={18} /></span><div><strong>Explainable signals</strong><span>See what shaped a prediction</span></div></div><div className="feature-item"><span className="feature-icon feature-mint"><Database size={18} /></span><div><strong>Local-first storage</strong><span>Analysis records in SQLite</span></div></div><div className="feature-item"><span className="feature-icon feature-violet"><FlaskConical size={18} /></span><div><strong>Honest evaluation</strong><span>Metrics from a held-out split</span></div></div></section>
          <section className="stats-grid" aria-label="Analysis statistics"><article className="stat-card"><div className="stat-label"><span className="stat-icon stat-icon-blue"><FileSearch size={17} /></span>Reviews analyzed</div><div className="stat-value">{dashboard ? dashboard.total.toLocaleString() : '—'}</div><div className="stat-caption">All-time checks in this database</div></article><article className="stat-card"><div className="stat-label"><span className="stat-icon stat-icon-green"><ThumbsUp size={17} /></span>Likely genuine</div><div className="stat-value">{dashboard ? dashboard.genuine.toLocaleString() : '—'}</div><div className="stat-caption">{dashboard?.total ? `${genuinePercent}% of analyzed reviews` : 'No reviews analyzed yet'}</div></article><article className="stat-card"><div className="stat-label"><span className="stat-icon stat-icon-amber"><CircleAlert size={17} /></span>Potentially fake</div><div className="stat-value">{dashboard ? dashboard.fake.toLocaleString() : '—'}</div><div className="stat-caption">A model prediction, not proof</div></article><article className="stat-card"><div className="stat-label"><span className="stat-icon stat-icon-violet"><Activity size={17} /></span>Macro F1</div><div className="stat-value">{evaluation?.available && evaluation.f1_macro !== undefined ? `${(evaluation.f1_macro * 100).toFixed(1)}%` : '—'}</div><div className="stat-caption">{evaluation?.available ? `Held-out test · ${evaluation.test_size} reviews` : 'Train the model to evaluate'}</div></article></section>
          <div className="overview-grid"><section className="panel chart-panel"><div className="panel-heading"><div><h2>Analysis activity</h2><p>Database-backed review checks over the last 14 days</p></div><span className="period-label"><Clock3 size={13} /> Last 14 days</span></div>{dashboardError ? <EmptyData title="Could not load analytics" detail={dashboardError.message} /> : <ReviewCharts dashboard={dashboard} />}</section><RecentAnalyses rows={recent} onViewAll={() => navigate('history')} /></div>
          {dashboardError && <div className="inline-service-note" role="status"><CircleAlert size={16} /><span>The Flask API is not responding. Start it locally with <code>python app.py</code> after training the model.</span></div>}
        </>}

        {view === 'analyze' && <section className="inner-page"><div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> TEXT CLASSIFICATION</div><h1>Analyze a review</h1><p>Enter the review as written. Product and star rating are optional context.</p></div><span className="heading-icon"><SearchCheck size={21} /></span></div><div className="analyze-layout"><section className="panel form-panel"><div className="panel-heading panel-heading-stacked"><div><h2>Review details</h2><p>Only review text is used by the baseline classifier.</p></div><span className="required-note">* required</span></div><form onSubmit={submitReview} className="review-form"><label className="field-label" htmlFor="product-name">Product name <span>Optional</span></label><input id="product-name" className="text-input" maxLength={120} placeholder="e.g. Wireless headphones" value={product} onChange={(event) => setProduct(event.target.value)} /><div className="field-row"><div className="field-column"><label className="field-label" htmlFor="rating">Star rating <span>Optional</span></label><select id="rating" className="text-input select-input" value={rating} onChange={(event) => setRating(event.target.value)}><option value="">Select a rating</option><option value="5">5 stars</option><option value="4">4 stars</option><option value="3">3 stars</option><option value="2">2 stars</option><option value="1">1 star</option></select></div><span className="context-hint"><CircleAlert size={15} /> Rating is stored as context and is not a model feature.</span></div><label className="field-label review-label" htmlFor="review-text">Review text <span className="required-mark">Required</span></label><textarea id="review-text" className="review-textarea" minLength={8} maxLength={5000} required placeholder="Paste the product review here. Keep its original wording and punctuation for the most useful analysis." value={review} onChange={(event) => setReview(event.target.value)} /><div className="textarea-meta"><span>Keep the original wording for a more useful analysis.</span><span>{review.length.toLocaleString()} / 5,000</span></div>{formError && <div className="form-error" role="alert"><CircleAlert size={16} />{formError}</div>}<button className="button-primary analyze-submit" type="submit" disabled={isSubmitting || review.trim().length < 8}>{isSubmitting ? <><span className="button-spinner" /> Analyzing review…</> : <>Analyze Review <ArrowRight size={17} /></>}</button><p className="privacy-note form-privacy"><ShieldCheck size={15} /> Review text is processed by the Flask service and saved in its local database.</p></form></section>
          {analysis ? <section className={`panel result-panel ${analysis.prediction === 'Genuine' ? 'result-genuine' : 'result-fake'}`} aria-live="polite"><div className="result-top"><div className="result-heading"><span className={`result-symbol ${analysis.prediction === 'Genuine' ? 'symbol-genuine' : 'symbol-fake'}`}>{analysis.prediction === 'Genuine' ? <ThumbsUp size={22} /> : <CircleAlert size={22} />}</span><div><span className="result-overline">MODEL PREDICTION</span><h2>{analysis.prediction === 'Genuine' ? 'Likely genuine' : 'Potentially fake'}</h2><p>This is a machine-learning classification, not a determination of authenticity.</p></div></div><div className="confidence-card"><span>Model probability</span><strong>{(analysis.probability * 100).toFixed(1)}%</strong><span>Not calibrated</span></div></div><div className="result-rule" /><div className="signal-heading"><div><h3>Signals to consider</h3><p>Heuristic cues are shown separately from the model prediction.</p></div><span className="signal-count">{analysis.indicators.filter((indicator) => indicator.present).length} of {analysis.indicators.length} observed</span></div><SignalList indicators={analysis.indicators} /><div className="result-disclaimer"><CircleAlert size={16} /><p>These are model and heuristic signals, not proof that the review is fake or genuine. The classifier and indicators can be wrong.</p></div></section> : <aside className="analysis-aside"><span className="aside-icon"><Sparkles size={19} /></span><h2>How the analysis works</h2><ol className="pipeline-list"><li><span>01</span><div><strong>Clean the text</strong><p>Normalize casing and accents; TF–IDF learns word and phrase patterns.</p></div></li><li><span>02</span><div><strong>TF–IDF features</strong><p>Represent word and phrase patterns as weighted numerical features.</p></div></li><li><span>03</span><div><strong>Classify + explain</strong><p>Logistic Regression predicts a label; separate heuristics show possible signals.</p></div></li></ol><div className="aside-disclaimer"><ShieldCheck size={16} /><span>Signals can be wrong. A prediction is not proof of authenticity.</span></div></aside>}</div></section>}

        {view === 'history' && <section className="inner-page"><div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> LOCAL SQLITE DATABASE</div><h1>Analysis history</h1><p>Saved analyses for this workspace. Review text is not returned by the history API.</p></div><span className="heading-icon"><History size={21} /></span></div><section className="panel history-panel"><div className="panel-heading"><div><h2>Recent reviews</h2><p>{historyData ? `${historyData.items.length} records · review text is not shown` : 'Loading saved analyses…'}</p></div><span className="period-label"><Database size={14} /> SQLite storage</span></div>{historyError ? <EmptyData title="History is unavailable" detail={historyError.message} /> : recent.length ? <div className="table-wrap"><table className="history-table"><thead><tr><th>PRODUCT</th><th>RATING</th><th>PREDICTION</th><th>MODEL PROBABILITY</th><th>ANALYZED</th></tr></thead><tbody>{recent.map((row) => <tr key={row.id}><td><span className="product-cell"><span className="product-cell-icon"><MessageSquareText size={15} /></span>{row.product_name || 'Product review'}</span></td><td>{row.rating ? `${row.rating}/5` : '—'}</td><td><StatusPill prediction={row.prediction} /></td><td><div className="probability-cell"><span>{(row.probability * 100).toFixed(1)}%</span><span className="probability-track"><i style={{ width: `${Math.round(row.probability * 100)}%` }} /></span></div></td><td>{formatDate(row.created_at)}</td></tr>)}</tbody></table></div> : <EmptyData title="No analyses yet" detail="Your saved results will appear here after you analyze a review." />}</section><div className="privacy-note"><ShieldCheck size={16} /><span>History shows product name, optional rating, prediction, and time only. Review text stays on the server and is not returned by this endpoint.</span></div></section>}

        {view === 'evaluation' && <section className="inner-page"><div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> HELD-OUT MODEL REPORT</div><h1>Model evaluation</h1><p>Metrics are generated by <code>train_model.py</code> from the current dataset split.</p></div><span className="heading-icon"><FlaskConical size={21} /></span></div>{evaluationError ? <section className="panel"><EmptyData title="Could not load evaluation" detail={evaluationError.message} /></section> : !evaluation?.available ? <section className="panel evaluation-empty"><span className="evaluation-empty-icon"><FlaskConical size={23} /></span><h2>Train the baseline to see real metrics</h2><p>{evaluation?.message ?? 'Training and test metrics will appear here after the classifier is trained.'}</p><div className="command-block"><code>python train_model.py</code><span>Uses dataset/reviews.csv by default</span></div><p className="evaluation-caveat">The included CSV is a small synthetic teaching example. Its held-out scores are not evidence of real-world performance.</p></section> : <><section className="evaluation-meta"><div><span>DATASET</span><strong>{evaluation.dataset_size} reviews</strong></div><div><span>TRAIN / TEST SPLIT</span><strong>{evaluation.training_size} / {evaluation.test_size}</strong></div><div><span>TRAINED</span><strong>{evaluation.trained_at ? formatDate(evaluation.trained_at) : '—'}</strong></div></section><section className="metrics-grid"><MetricCard label="Accuracy" value={evaluation.accuracy} /><MetricCard label="Macro precision" value={evaluation.precision_macro} hint="Balances both classes" /><MetricCard label="Macro recall" value={evaluation.recall_macro} hint="Balances both classes" /><MetricCard label="Macro F1" value={evaluation.f1_macro} hint="Precision–recall balance" /></section><section className="panel confusion-panel"><div className="panel-heading"><div><h2>Confusion matrix</h2><p>Counts on held-out examples · rows are actual classes</p></div><span className="period-label">Actual ↓ &nbsp; Predicted →</span></div>{evaluation.confusion_matrix && evaluation.labels ? <div className="table-wrap"><table className="matrix-table"><thead><tr><th>ACTUAL</th>{evaluation.labels.map((label) => <th key={label}>{label}</th>)}</tr></thead><tbody>{evaluation.confusion_matrix.map((row, rowIndex) => <tr key={evaluation.labels?.[rowIndex]}><th>{evaluation.labels?.[rowIndex]}</th>{row.map((count, colIndex) => <td className={rowIndex === colIndex ? 'matrix-correct' : 'matrix-error'} key={`${rowIndex}-${colIndex}`}>{count}</td>)}</tr>)}</tbody></table></div> : <EmptyData title="Confusion matrix unavailable" detail="Retrain the model to regenerate its evaluation report." />}</section><p className="evaluation-caveat evaluation-note"><CircleAlert size={16} />{evaluation.evaluation_note}</p></> }</section>}
      </main>
      <footer className="app-footer"><span>Proofline <span className="footer-divider">/</span> Educational demonstration</span><span>Predictions are signals, not proof.</span></footer>
    </div>
  </div>
}

export { fetcher }
export type { Dashboard, Evaluation, HistoryRow }
