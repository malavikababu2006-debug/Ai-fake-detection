'use client'

import { BarElement, CategoryScale, Chart as ChartJS, Filler, Legend, LinearScale, LineElement, PointElement, ArcElement, Tooltip } from 'chart.js'
import { Doughnut, Line } from 'react-chartjs-2'
import type { Dashboard } from '@/components/review-detection-app'

ChartJS.register(ArcElement, BarElement, CategoryScale, Filler, Legend, LineElement, LinearScale, PointElement, Tooltip)

export function ReviewCharts({ dashboard }: { dashboard?: Dashboard }) {
  const byDay = new Map((dashboard?.daily_activity ?? []).map((row) => [row.day, row]))
  const today = new Date()
  const days = Array.from({ length: 14 }, (_, index) => {
    const date = new Date(today)
    date.setDate(today.getDate() - (13 - index))
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
    return { key, label: date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), ...byDay.get(key) }
  })
  const activity = {
    labels: days.map((day) => day.label),
    datasets: [
      { label: 'Genuine', data: days.map((day) => day.genuine ?? 0), borderColor: '#2d9b80', backgroundColor: 'rgba(45, 155, 128, .12)', fill: true, tension: .36, pointRadius: 2, pointHoverRadius: 5 },
      { label: 'Potentially fake', data: days.map((day) => day.fake ?? 0), borderColor: '#d9944c', backgroundColor: 'rgba(217, 148, 76, .08)', fill: true, tension: .36, pointRadius: 2, pointHoverRadius: 5 },
    ],
  }
  const breakdown = {
    labels: ['Likely genuine', 'Potentially fake'],
    datasets: [{ data: [dashboard?.genuine ?? 0, dashboard?.fake ?? 0], backgroundColor: ['#2d9b80', '#e5a253'], borderWidth: 0, hoverOffset: 5 }],
  }
  const commonOptions = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { displayColors: false, padding: 10 } } }
  return <div className="charts-layout"><div className="activity-chart"><div className="chart-legend"><span><i className="legend-genuine" /> Likely genuine</span><span><i className="legend-fake" /> Potentially fake</span></div><div className="line-chart-wrap"><Line role="img" aria-label="Daily genuine and potentially fake review-analysis counts for the last two weeks" data={activity} options={{ ...commonOptions, interaction: { intersect: false, mode: 'index' as const }, scales: { x: { grid: { display: false }, border: { display: false }, ticks: { color: '#849097', maxTicksLimit: 7, font: { size: 10 } } }, y: { beginAtZero: true, border: { display: false }, grid: { color: '#edf0ef' }, ticks: { precision: 0, color: '#849097', font: { size: 10 } } } } }} /></div></div><div className="breakdown-chart"><h3>Prediction split</h3><div className="doughnut-wrap"><Doughnut role="img" aria-label="Proportion of likely genuine and potentially fake review predictions" data={breakdown} options={{ ...commonOptions, cutout: '75%', plugins: { legend: { display: false }, tooltip: { displayColors: false, padding: 10 } } }} /><div className="doughnut-center"><strong>{dashboard?.total ?? 0}</strong><span>analyzed</span></div></div><div className="breakdown-labels"><span><i className="legend-genuine" />Genuine <strong>{dashboard?.genuine ?? 0}</strong></span><span><i className="legend-fake" />Potentially fake <strong>{dashboard?.fake ?? 0}</strong></span></div></div></div>
}
