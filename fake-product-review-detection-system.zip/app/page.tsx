import { ReviewDetectionApp } from '@/components/review-detection-app'

export default function Page() {
  return <ReviewDetectionApp />
}
