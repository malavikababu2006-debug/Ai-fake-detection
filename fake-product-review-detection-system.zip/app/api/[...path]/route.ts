import { NextRequest, NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

async function proxy(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const { path } = await context.params
  const baseUrl = process.env.FLASK_API_URL ?? 'http://127.0.0.1:5000'
  const target = new URL(`/api/${path.map(encodeURIComponent).join('/')}`, baseUrl)
  target.search = request.nextUrl.search

  try {
    const response = await fetch(target, {
      method: request.method,
      headers: request.headers.get('content-type') ? { 'content-type': request.headers.get('content-type')! } : undefined,
      body: request.method === 'GET' || request.method === 'HEAD' ? undefined : await request.text(),
      cache: 'no-store',
      signal: AbortSignal.timeout(15_000),
    })
    const payload = await response.text()
    return new NextResponse(payload, {
      status: response.status,
      headers: { 'content-type': response.headers.get('content-type') ?? 'application/json; charset=utf-8', 'cache-control': 'no-store' },
    })
  } catch {
    return NextResponse.json({ error: 'The Flask analysis service is unavailable. Start the API or check FLASK_API_URL.' }, { status: 503 })
  }
}

export const GET = proxy
export const POST = proxy
